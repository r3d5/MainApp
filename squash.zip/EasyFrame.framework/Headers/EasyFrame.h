//
//  EasyFrame.h
//  EasyFrame
//
//  Created by Maksym Tsymbal on 25/07/2018.
//  Copyright © 2018 Maksym Tsymbal. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for EasyFrame.
FOUNDATION_EXPORT double EasyFrameVersionNumber;

//! Project version string for EasyFrame.
FOUNDATION_EXPORT const unsigned char EasyFrameVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EasyFrame/PublicHeader.h>


